# PySnips

[![PyPI Version](https://img.shields.io/pypi/v/pysnips.svg)](https://pypi.org/project/pysnips/)
[![Python Version](https://img.shields.io/pypi/pyversions/pysnips.svg)](https://pypi.org/project/pysnips/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code Style: Black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

**PySnips** is a high-performance, production-quality CLI tool designed to accelerate Python development. It provides a library of **50+ expertly crafted code templates** spanning from core language syntax to advanced Machine Learning and AI Full-Stack architectures.

---

## Project Information

- **Author**: DevTools Engineer
- **GitHub**: [anusha-b2803/pysnips](https://github.com/anusha-b2803/pysnips)
- **PyPI**: [pypi.org/project/pysnips](https://pypi.org/project/pysnips/)
- **Bug Tracker**: [GitHub Issues](https://github.com/anusha-b2803/pysnips/issues)

---

## Key Features

- **50+ Specialized Templates**: Instantly generate boilerplate for Basic Python, ML, Deep Learning, and FastAPI.
- **Dynamic Injection**: Fully customizable snippets using CLI flags (e.g., `--name MyModel --lr 0.01`).
- **Zero Dependencies**: Built entirely on the Python Standard Library for maximum compatibility and minimal footprint.
- **Clean Architecture**: Engineered with a modular registry system, making it easy to extend and maintain.
- **Developer First**: Outputs clean, PEP-8 compliant code directly to your terminal or into a file.

---

## Installation

The easiest way to install PySnips is via **pip**:

```bash
pip install pysnips
```
### Install from Source

For development or local modifications:

```bash
git clone https://github.com/anusha-b2803/pysnips.git
cd pysnips
pip install -e .
```

---

## Quick Start

### 1. Explore Available Snippets
List all 50+ available commands categorized by domain:
```bash
pysnips list
```

### 2. Generate a Python Function
```bash
pysnips func --name calculate_metrics --args "data, threshold"
```

### 3. Scaffold a FastAPI Application
Generate a complete API boilerplate and save it directly to a file:
```bash
pysnips fastapi-app --title "Predictive Analytics API" > main.py
```

### 4. Build a Machine Learning Pipeline
```bash
pysnips random-forest --n_estimators 200 > train.py
```

---

## Category Overview

| Category | Description | Examples |
| :--- | :--- | :--- |
| **BASIC** | Core Python syntax & control flow | `for`, `tryfull`, `listcomp` |
| **MACHINE LEARNING** | Scikit-learn model boilerplates | `svm`, `random-forest`, `pca` |
| **DEEP LEARNING** | Keras/TensorFlow architectures | `cnn-image`, `lstm`, `nn-train` |
| **ML PIPELINE** | Data engineering & preprocessing | `scaler`, `train-test`, `pipeline` |
| **AI FULL-STACK** | FastAPI, DB connections & Logging | `fastapi-app`, `db-connect`, `ml-api` |

<details>
<summary><b>Click to see all 50+ templates</b></summary>

### BASIC
- `for`, `while`, `if`, `ifelse`, `elif`, `try`, `tryfull`, `func`, `rfunc`, `listcomp`, `dictcomp`, `setcomp`, `lambda`, `maincheck`, `printfmt`

### MACHINE LEARNING
- `linear-reg`, `logistic-reg`, `knn`, `svm`, `decision-tree`, `random-forest`, `naive-bayes`, `kmeans`, `pca`, `model-eval`

### DEEP LEARNING
- `nn-basic`, `nn-compile`, `nn-train`, `cnn-basic`, `cnn-image`, `rnn-basic`, `lstm`, `dropout`, `predict`, `save-load-dl`

### ML PIPELINE
- `data-load`, `data-clean`, `train-test`, `scaler`, `pipeline`

### AI FULL-STACK
- `fastapi-app`, `route-get`, `route-post`, `ml-api`, `file-upload`, `json-response`, `async-api`, `db-connect`, `save-predict`, `logger`

</details>

---

## Project Architecture

PySnips is built with scalability in mind:

- `pysnips/cli.py`: Advanced argument parsing and UI handling.
- `pysnips/registry.py`: Centralized template management system.
- `pysnips/generator.py`: Regex-powered dynamic template engine.
- `pysnips/utils/`: Enhanced console formatting and color support.

---

## License

Distributed under the **MIT License**. See [LICENSE](LICENSE) for more information.

---

<p align="center">
  Built for the Python Community
</p>
